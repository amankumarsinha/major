package com.coign.student_ebridge;

public class Constants {

	public static final String ACCESS_KEY_ID = "AKIAIE62EN4OYI4UFTXA";
	public static final String SECRET_KEY = "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";

}
